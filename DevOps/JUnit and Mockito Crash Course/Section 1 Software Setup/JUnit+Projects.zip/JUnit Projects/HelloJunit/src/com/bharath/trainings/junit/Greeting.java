package com.bharath.trainings.junit;

public interface Greeting {
	String greet(String name);
}
