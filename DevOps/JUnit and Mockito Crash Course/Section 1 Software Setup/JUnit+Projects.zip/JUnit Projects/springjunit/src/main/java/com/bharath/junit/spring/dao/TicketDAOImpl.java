package com.bharath.junit.spring.dao;

import com.bharath.junit.spring.dto.Ticket;

public class TicketDAOImpl implements TicketDAO {

	public int createTicket(Ticket ticket) {
		return 1;
	}

}
