package com.bharaththippireddy.mockito.mockitoargumenttypes;

public class ParamObject {

}
