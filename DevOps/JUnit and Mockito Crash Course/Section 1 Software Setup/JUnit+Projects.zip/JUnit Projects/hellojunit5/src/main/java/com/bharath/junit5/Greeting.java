package com.bharath.junit5;

public interface Greeting {
	String greet(String name);
}
