package com.bharath.mockito.scrapbook;

public class B {

	public void voidmethod() throws Exception {

	}
}
