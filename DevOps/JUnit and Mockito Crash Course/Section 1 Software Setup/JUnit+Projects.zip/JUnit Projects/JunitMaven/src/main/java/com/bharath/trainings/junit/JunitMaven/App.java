package com.bharath.trainings.junit.JunitMaven;

/**
 * Hello world!
 *
 */
public class App {

	public String getWish() {
		return "Hello";
	}

}
