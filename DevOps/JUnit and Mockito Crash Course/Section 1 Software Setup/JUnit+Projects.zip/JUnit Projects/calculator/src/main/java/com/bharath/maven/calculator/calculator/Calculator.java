package com.bharath.maven.calculator.calculator;

public interface Calculator {

	int add(int num1, int num2);
}
