package com.bharath.maven.calculator.calculator;

public class CalculatorImpl implements Calculator {

	public int add(int num1, int num2) {
		return num1 + num2;
	}

}
