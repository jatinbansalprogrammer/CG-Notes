package com.infiniteskills.maven;

public class ExcludeMe {

}
