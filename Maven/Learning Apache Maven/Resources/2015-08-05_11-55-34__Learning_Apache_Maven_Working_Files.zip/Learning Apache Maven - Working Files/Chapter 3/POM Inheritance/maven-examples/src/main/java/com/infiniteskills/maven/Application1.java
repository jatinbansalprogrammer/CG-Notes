package com.infiniteskills.maven;

/**
 * 
 * @author Kevin Bowersox
 * This class is used to test Maven
 */
public class Application1 {

	public static void main(String[] args) {
		System.out.println("Hello World");
	}
}
