package com.infiniteskills.maven;

public class Application2 {

}
