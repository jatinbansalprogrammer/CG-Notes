package com.infiniteskills.maven;

import org.apache.commons.lang3.StringUtils;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	StringUtils.isAllLowerCase("test");
        System.out.println( "Hello World! Test" );
    }
}
