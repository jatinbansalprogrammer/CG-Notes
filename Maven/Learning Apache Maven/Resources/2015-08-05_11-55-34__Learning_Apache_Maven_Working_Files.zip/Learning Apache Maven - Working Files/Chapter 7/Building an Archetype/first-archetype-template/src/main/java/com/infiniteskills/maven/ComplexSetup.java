package com.infiniteskills.maven;

public class ComplexSetup {

}
