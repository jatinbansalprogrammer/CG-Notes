package com.infiniteskills.template;

public class ComplexSetup {

}
