export interface CustomHttpRespone {
  httpStatusCode: number;
  httpStatus: string;
  reson: string;
  message: string;

}
