package com.pluralsight.hazelcast.shared;

/**
 * Grant Little grant@grantlittle.me
 */
public interface MapNames {

    String CUSTOMERS_MAP = "customers";
}
